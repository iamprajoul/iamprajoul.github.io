// Author: Jenisha Kathayat C0900836, Prajwal shrestha, Nishan Shrestha, Amrit Rimal
// providing information from alert

   alert("🚨 Attention: You've been flagged for exceeding the speed limit. Please pull over safely.");

var driverName, licenseNumber, licenseCheck, permitCheck, insuranceCheck, seatBeltCheck;

// declaring a function
 function generateTicket(event){
    event.preventDefault();
    console.log("this is first line");
    // fetching the value and storing in the variable
    var driverName = document.getElementById("name").value;
    var licenseNumber = document.getElementById("number").value;

    if(driverName.trim()==="" || licenseNumber.trim()===""){
        document.getElementById("errorText").innerHTML = "Name and Number cannot be empty!!";
        return;
    }
    else{
        $("#errorText").hide();
        

        console.log("this is after else line");
    // declaring variable and assigning 0 or 1
    var licenseCheck = parseInt(Math.random()*2);
    var permitCheck = parseInt(Math.random()*2);
    var insuranceCheck = parseInt(Math.random()*2);
    var seatBeltCheck = parseInt(Math.random()*2);

    // assigning a value to variable using if-else
    var validate = function(num){
        if (num==0){
            return "Invalid";
        }
        else{
            return "Valid";
        }
    }

    // printing output to console to check the code
    console.log("Name: "+driverName);
    console.log("\nLicense Number: "+licenseNumber);
    console.log("\nDriver's License: "+ validate(licenseCheck));
    console.log("\nDriver's Permit: "+ validate(permitCheck));
    console.log("\nDriver's Insurance: "+ validate(insuranceCheck));
    console.log("\nSeat Belt Check: "+ validate(seatBeltCheck));

    

// declaring variables for further calculations and string concatenation
var total=0,offenseDetails=" ";
var km = Math.floor(Math.random()*61);

// setting fine according to kms driven while overspeeding
if (km>=50){
   offenseDetails += "Court settlement required for speeding.\n";
}
else if (km>=30){
   offenseDetails += "You were recorded speeding for more than 29kms.\n";
   total = km * 6;
}
else if (km>=20){
   offenseDetails += "You were recorded speeding for more than 19kms.\n";
   total = km * 3.75;
}
else {
   offenseDetails += "You were recorded speeding for "+km+"km.\n";
   total = km * 2.5;
}


// checking for the license and setting the fine
if (licenseCheck==0){
   offenseDetails +="Section: 32(1) \nOffence name:Improper or no license."+"\n";
   total = total +260;
}

// checking for the permit and setting the fine
if (permitCheck==0){
   offenseDetails +="Section: 7(1) \nOffence name:No valid permit"+"\n";
   total = total + 85;
}

// checking for the insurance and giving a warning
if (insuranceCheck==0){
   offenseDetails +="Section: 23(1) \nOffence name:Improper insurance \nGive the warning!!!"+"\n";
}

// checking for the seat belt and setting the fine
if (seatBeltCheck==0){
   offenseDetails +="Section: 106(2) \nOffence name:Fail to properly wear seat belt"+"\n";
   total = total + 200;
}
// printing output in html (displaying to user)
document.getElementById("p1").innerHTML= new Date();
document.getElementById("p2").innerHTML= "Ticket number: "+ Math.floor(Math.random()*10000001);
document.getElementById("p3").innerHTML= "Driver's name: "+driverName;
document.getElementById("p4").innerHTML= "License number: "+ licenseNumber;
// printing the output of above calculation
document.getElementById("off1").innerHTML=offenseDetails;
document.getElementById("Total").innerHTML= "Total fine is $"+total+".";

    }

    console.log("this is outside else line");
$("#span1").t({
   speed: 15,
   caret: "_",
   blink: true,
  
});

// Show the #span1 div
$("#span1").show();
 };

 


 




    

